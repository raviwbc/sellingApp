export const APP_CONSTANTS = {
    SERVICE_BASE_URL: "http://localhost:3000",   
    API: {

        // FIND BOOKING DETAILS 

        REGISTOR: '/registration',

        CURRENTBID : '/currentBid',
        CURRENTAUTHIS : '/currentautHistory',
        COMPLETEDLIST :'/completedList',
        TEAMLIST:'/teamList'
        
    }
}
